﻿using Microsoft.EntityFrameworkCore;
using Projekt3.Models.Domain;
namespace Projekt3.Data
{
    public class CrudDBContext : DbContext
    {
        public CrudDBContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<Employee> Employees { get; set; }

    }
}
