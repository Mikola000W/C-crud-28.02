﻿
namespace Projekt3.Models
{
    public class AddEmployeeViewModel
    {

        public string Name { get; set; }

        public string Email { get; set; }

        public long Salary { get; set; }

        public DateTime Birthdate { get; set; }

        public int Position { get; set; }

    }
}